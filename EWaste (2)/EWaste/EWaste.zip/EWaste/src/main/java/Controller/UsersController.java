package Controller;

import Model.Users;

import Service.impl.serviceimpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class UsersController {

    @Autowired
    serviceimpl userservice;


    @GetMapping("hi")
    public String greetings(){
        return "hiii";
    }

    @GetMapping("/get")
    public String user()
    {
        return "helloworld";
    }

    @PostMapping("/post")
    public Users saveUsers(@RequestBody Users users){
        return userservice.create(users);
    }
}