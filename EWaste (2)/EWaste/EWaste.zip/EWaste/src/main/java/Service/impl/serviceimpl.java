package Service.impl;


import Model.Users;
import Repository.UsersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class serviceimpl  {

    @Autowired
    UsersRepository usersrepository;


    public Users create(Users users) {
        return usersrepository.save(users);
    }
}