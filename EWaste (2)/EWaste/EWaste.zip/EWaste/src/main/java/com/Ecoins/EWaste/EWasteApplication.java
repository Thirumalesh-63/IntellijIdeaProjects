package com.Ecoins.EWaste;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EWasteApplication {

	public static void main(String[] args) {
		SpringApplication.run(EWasteApplication.class, args);
	}
}
