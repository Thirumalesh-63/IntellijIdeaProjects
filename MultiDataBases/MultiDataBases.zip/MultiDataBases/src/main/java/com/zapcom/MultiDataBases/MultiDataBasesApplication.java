package com.zapcom.MultiDataBases;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MultiDataBasesApplication {

	public static void main(String[] args) {
		SpringApplication.run(MultiDataBasesApplication.class, args);
	}

}
