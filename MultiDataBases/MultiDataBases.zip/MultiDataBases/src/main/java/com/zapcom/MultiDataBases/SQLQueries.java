package com.zapcom.MultiDataBases;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;


@Component
public class SQLQueries {


    private  JdbcTemplate mysqlJdbcTemplate;

    @Autowired
    public SQLQueries(JdbcTemplate mysqlJdbcTemplate) {

        this.mysqlJdbcTemplate = mysqlJdbcTemplate;
    }
    public Integer findById(int id){
        // Step 1: Check if the user exists in the database
        String checkSql = "SELECT COUNT(*) FROM user WHERE id = ?";
        return mysqlJdbcTemplate.queryForObject(checkSql, Integer.class, id);

    }

    public void updateRecord(User user){
        String updateSql = "UPDATE user SET name = ? WHERE id = ?";
        mysqlJdbcTemplate.update(updateSql, user.getName(), user.getId());
    }

    public void saveRecord(User user){
        String insertSql = "INSERT INTO user (id, name) VALUES (?, ?)";
        mysqlJdbcTemplate.update(insertSql, user.getId(), user.getName());
    }

}
