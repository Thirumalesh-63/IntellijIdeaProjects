package com.zapcom.MultiDataBases;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

import static java.lang.System.*;

@Service
public class Service1 {

    private  JdbcTemplate h2JdbcTemplate;
    private  JdbcTemplate mysqlJdbcTemplate;

    @Autowired
    public Service1(JdbcTemplate h2JdbcTemplate, JdbcTemplate mysqlJdbcTemplate) {
        this.h2JdbcTemplate = h2JdbcTemplate;
        this.mysqlJdbcTemplate = mysqlJdbcTemplate;
    }

    @Autowired
    private SQLQueries quereis;

    // H2 Operations
    public void h2database() {
        String sql = "Select * from MY_TABLE";
        System.err.println(h2JdbcTemplate.queryForList(sql));
    }

    public String sqldatabase(User user) {
            Integer count = quereis.findById(user.getId());

            if (count > 0) {
                quereis.updateRecord(user);
               return "User updated successfully";
            } else {

                quereis.saveRecord(user);
               return  "User inserted successfully.";            }
        }




}
