package com.zapcom.mapstruct;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MapstructApplicationTests {

	@Test
	void contextLoads() {
	}

}
